# RIFD Foundation Website

Built with Next.js, React, TypeScript and Tailwind CSS.

## Build status
- [x] Phase 1: Brand and design system
- [ ] Phase 2: Core website
- [ ] Phase 3: Humanitarian features
- [ ] Phase 4: Donations and forms
- [ ] Phase 5: Admin and backend
- [ ] Phase 6: Final polish

## Brand colours (from the logo)
Green #0E6B45, Deep green #0A4A32, Gold #C9A03A, Cream #FDFCF7.
Edit them in `tailwind.config.ts`.
