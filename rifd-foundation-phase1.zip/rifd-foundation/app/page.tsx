// PHASE 1 page: shows the brand system so you can confirm it looks right.
// In Phase 2 this file becomes the real homepage.

const colours = [
  { name: "Primary green", hex: "#0E6B45", use: "Buttons, links, logo", cls: "bg-rifd-green", light: true },
  { name: "Deep green", hex: "#0A4A32", use: "Headings, footer", cls: "bg-rifd-deep", light: true },
  { name: "Gold", hex: "#C9A03A", use: "Accents, highlights", cls: "bg-rifd-gold", light: false },
  { name: "Mist", hex: "#EAF2ED", use: "Soft sections", cls: "bg-rifd-mist", light: false },
  { name: "Cream", hex: "#FDFCF7", use: "Page background", cls: "bg-rifd-cream border border-rifd-green/20", light: false },
  { name: "Ink", hex: "#12261D", use: "Body text", cls: "bg-rifd-ink", light: true },
];

export default function Home() {
  return (
    <main>
      <section className="mx-auto max-w-page px-5 py-12 text-center sm:py-20">
        {/* The logo is shown untouched, at its original proportions. */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/logo.jpeg"
          alt="RIFD Foundation logo: Supporting Lives, Building Hope"
          width={1280}
          height={1249}
          className="mx-auto h-auto w-56 sm:w-72"
        />
        <h1 className="mx-auto mt-10 max-w-2xl text-4xl leading-tight sm:text-6xl">
          Together, we can change lives.
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-lg text-rifd-ink/80">
          Phase 1 is complete. This page confirms your brand colours, fonts and buttons are working.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <span className="btn-primary">Donate Now</span>
          <span className="btn-outline">Explore Our Projects</span>
          <span className="btn-gold">Make a Difference Today</span>
        </div>
      </section>

      <section className="bg-rifd-mist px-5 py-14">
        <div className="mx-auto max-w-page">
          <h2 className="text-3xl sm:text-4xl">Brand colours</h2>
          <p className="mt-2 max-w-xl text-rifd-ink/80">
            Matched to the supplied logo. Every page in the website will use only these.
          </p>
          <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {colours.map((c) => (
              <li key={c.hex} className="bg-white p-3 shadow-sm">
                <div className={`${c.cls} flex h-24 items-end p-3 text-sm font-semibold ${c.light ? "text-white" : "text-rifd-deep"}`}>
                  {c.hex}
                </div>
                <p className="mt-3 font-semibold text-rifd-deep">{c.name}</p>
                <p className="text-sm text-rifd-ink/70">{c.use}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-page px-5 py-14">
        <h2 className="text-3xl sm:text-4xl">Typography</h2>
        <p className="mt-4 font-display text-2xl text-rifd-deep">
          Newsreader for headlines: a refined serif that echoes the RIFD lettering.
        </p>
        <p className="mt-3 max-w-xl text-lg">
          Figtree for body text: clean, friendly and easy to read on a phone.
        </p>
      </section>

      <footer className="bg-rifd-deep px-5 py-8 text-center text-sm text-white/80">
        RIFD Foundation. Supporting Lives, Building Hope.
      </footer>
    </main>
  );
}
