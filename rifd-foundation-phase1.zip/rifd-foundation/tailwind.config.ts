import type { Config } from "tailwindcss";

// RIFD brand colours, taken from the official logo.
// To change a colour later, edit it here and in app/globals.css.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        rifd: {
          green: "#0E6B45",   // primary: logo "R" and "RIFD" lettering
          deep: "#0A4A32",    // darker green: text, footer, hover states
          gold: "#C9A03A",    // accent: logo wing, divider lines, heart icon
          cream: "#FDFCF7",   // logo background
          mist: "#EAF2ED",    // very light green tint for soft sections
          ink: "#12261D",     // body text (green-black, not pure black)
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      maxWidth: { page: "72rem" },
    },
  },
  plugins: [],
};
export default config;
